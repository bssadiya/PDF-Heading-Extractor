from fpdf import FPDF

pdf = FPDF()
pdf.set_auto_page_break(auto=True, margin=15)

for page in range(1, 51):
    pdf.add_page()
    
    pdf.set_font("Arial", "B", 18)
    pdf.cell(0, 10, f"H1: Chapter {page}", ln=True)

    pdf.set_font("Arial", "B", 14)
    pdf.cell(0, 10, f"H2: Section {page}.1", ln=True)

    pdf.set_font("Arial", "B", 11)
    pdf.cell(0, 10, f"H3: Subsection {page}.1.1", ln=True)

    pdf.ln(10)
    pdf.set_font("Arial", "", 10)
    for _ in range(5):
        pdf.multi_cell(0, 10, f"This is sample paragraph text for page {page}. " * 2)

pdf.output("Large_Technical_Document.pdf")
